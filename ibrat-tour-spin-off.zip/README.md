# IBRAT TOUR SPIN-OFF — veb-sayt

React + Vite asosidagi bir sahifali sayt. Barcha rasmiy ma’lumotlar
**3 sentabr 2026-yildagi 64-F/B-sonli buyruq**ga (`public/docs/buyruq-64-F-B.pdf`) asoslangan.
Hujjatda bo‘lmagan ma’lumotlar “Ma’lumot kiritilmagan” yoki “Demo” deb belgilangan.

## Ishga tushirish

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # tayyor sayt: dist/
npm run preview    # dist/ ni tekshirish
```

Node.js 18+ (tavsiya: 22) kerak.

## Ma’lumotlarni yangilash (kod yozmasdan)

Barcha matnlar `src/data/` papkasida:

| Fayl | Nima uchun |
| --- | --- |
| `site.js` | Buyruq rekvizitlari, **aloqa ma’lumotlari** (`CONTACT`) |
| `services.js` | Xizmatlar (guruhlar va bandlar) |
| `routes.js` | Marshrut kartochkalari (hozir hammasi Demo) |
| `news.js` | Yangiliklar (hozir hammasi Demo) |
| `faq.js` | Savol-javoblar |
| `students.js`, `digital.js`, `partnership.js` | Tegishli bo‘lim matnlari |

**Aloqa:** `src/data/site.js` dagi `CONTACT` ni to‘ldiring (telefon, email, manzil, ijtimoiy tarmoqlar).
Ma’lumot kiritilgach, “Aloqa” bo‘limidagi havolalar va “Email orqali yuborish” tugmasi avtomatik yoqiladi.

**Real marshrut qo‘shish:** `routes.js` da yangi obyekt qo‘shing va `demo: false` qiling.

## Papkalar

```
public/            statik fayllar (favicon, robots.txt, docs/buyruq-64-F-B.pdf)
src/data/          matn va ma’lumotlar
src/components/    ui/ (tugma, modal, ikonka...), layout/ (header, footer), sections/ (bo‘limlar)
src/hooks/         useTheme, useRevealOnScroll, useActiveSection
src/styles/        tokens.css (ranglar, rejimlar), base.css, layout.css, sections.css
```

## Deploy

### Netlify (eng oson)
1. Loyihani GitHub’ga yuklang.
2. app.netlify.com → **Add new site → Import an existing project → GitHub** → repozitoriyni tanlang.
3. Sozlamalar `netlify.toml` dan avtomatik olinadi (`npm run build`, `dist`). **Deploy** bosing.

### GitHub Pages
1. Repozitoriyni `main` branch bilan yuklang.
2. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. `main` ga har push qilinganda `.github/workflows/deploy.yml` saytni avtomatik joylaydi.
   Manzil: `https://<username>.github.io/<repo>/`
