import Header from './components/layout/Header.jsx'
import Footer from './components/layout/Footer.jsx'
import Hero from './components/sections/Hero.jsx'
import Highlights from './components/sections/Highlights.jsx'
import About from './components/sections/About.jsx'
import Services from './components/sections/Services.jsx'
import RoutesSection from './components/sections/RoutesSection.jsx'
import Students from './components/sections/Students.jsx'
import DigitalTourism from './components/sections/DigitalTourism.jsx'
import Partnership from './components/sections/Partnership.jsx'
import News from './components/sections/News.jsx'
import Faq from './components/sections/Faq.jsx'
import OfficialDocument from './components/sections/OfficialDocument.jsx'
import Contact from './components/sections/Contact.jsx'
import useTheme from './hooks/useTheme.js'
import useRevealOnScroll from './hooks/useRevealOnScroll.js'

export default function App() {
  const { theme, toggle } = useTheme()
  useRevealOnScroll()

  return (
    <>
      <a className="skip-link" href="#asosiy">
        Asosiy mazmunga o‘tish
      </a>
      <Header theme={theme} onToggleTheme={toggle} />
      <main id="asosiy" tabIndex={-1}>
        <Hero />
        <Highlights />
        <About />
        <Services />
        <RoutesSection />
        <Students />
        <DigitalTourism />
        <Partnership />
        <News />
        <Faq />
        <OfficialDocument />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
