import { useEffect } from 'react'

// `.reveal` klassli elementlar ekranga kirganda `is-visible` klassini oladi.
export default function useRevealOnScroll() {
  useEffect(() => {
    const items = Array.from(document.querySelectorAll('.reveal'))
    if (!items.length) return undefined

    if (!('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'))
      return undefined
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible')
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.08, rootMargin: '0px 0px -6% 0px' },
    )

    items.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])
}
