export const FAQ = [
  {
    q: 'IBRAT TOUR SPIN-OFF nima?',
    a: '“IBRAT TOUR SPIN-OFF” — Is’hoqxon Ibrat nomidagi Namangan davlat chet tillari instituti tasarrufida tashkil etish belgilangan mas’uliyati cheklangan jamiyat (MCHJ). Uning maqsadi — institutning ilmiy-innovatsion ishlanmalarini turizm sohasida amaliyotga joriy etish, turizm xizmatlari bozorida raqobatbardosh mahsulot yaratish va talabalarning amaliy ko‘nikmalarini shakllantirish.',
  },
  {
    q: 'Qachon tashkil etilgan?',
    a: 'Jamiyatni tashkil etish to‘g‘risidagi buyruq 2026-yil 3-sentabrda 64-F/B raqami bilan qabul qilingan. Davlat ro‘yxatidan o‘tkazish buyruqda belgilangan tartibda amalga oshiriladi. Ro‘yxatdan o‘tish sanasi va boshqa rekvizitlar hozircha kiritilmagan.',
  },
  {
    q: 'Qaysi xizmatlarni ko‘rsatadi?',
    a: 'Buyruqda quyidagi yo‘nalishlar belgilangan: turizm (turoperatorlik, turagentlik), ekskursiya va gidlik, turizm turlari, sayohat logistikasi, ta’lim, IT va raqamli turizm, marketing va kontent. To‘liq ro‘yxat “Xizmatlar” bo‘limida. Xizmat narxlari va buyurtma tartibi hozircha kiritilmagan.',
  },
  {
    q: 'Talabalar qanday yo‘nalishlarda qatnashishi mumkin?',
    a: 'Buyruqda talabalarning amaliy ko‘nikmalarini shakllantirish maqsad qilib qo‘yilgan. “Talabalar” bo‘limida shu maqsadga mos yo‘nalishlar ko‘rsatilgan: gidlik va tarjimonlik, turistik kontent, IT va raqamli turizm, marketing, turizm loyihalari. Qabul tartibi va shartlari hozircha kiritilmagan.',
  },
  {
    q: 'Turistik marshrutlar qanday tashkil qilinadi?',
    a: 'Buyruqda turistik marshrutlarni ishlab chiqish, sinovdan o‘tkazish va pasportlashtirish, shuningdek gid hamrohligida oldindan tuzilgan yo‘nalishlar bo‘yicha ekskursiyalar tashkil etish faoliyati belgilangan. Saytdagi marshrut kartochkalari hozircha Demo.',
  },
  {
    q: 'Gid va tarjimon xizmatlari bormi?',
    a: 'Ha, buyruqda gid, gid-tarjimon va ekskursovod xizmatlarini ko‘rsatish hamda tarjimonlik va til ko‘magi xizmatlari faoliyat yo‘nalishi sifatida belgilangan. Xizmat shartlari va narxlari hozircha kiritilmagan.',
  },
  {
    q: 'Raqamli turizm xizmatlari bormi?',
    a: 'Ha, buyruqda audiogid, elektron gid va raqamli ekskursiya kontentini ishlab chiqish va tarqatish, turizm platformalari, web-saytlar va mobil ilovalarni yaratish, ma’lumotlarni qayta ishlash va hosting yo‘nalishlari belgilangan.',
  },
]
