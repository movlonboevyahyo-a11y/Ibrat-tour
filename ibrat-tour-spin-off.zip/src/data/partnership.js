export const PARTNERSHIP_AREAS = [
  {
    icon: 'plane',
    title: 'Turizm xizmatlari',
    text: 'Turoperatorlik va turagentlik: ichki, kirish va chiqish turizmi yo‘nalishlarida.',
  },
  {
    icon: 'users',
    title: 'MICE tadbirlari',
    text: 'Konferensiya, seminar, forum, ko‘rgazma va yarmarkalarni tashkil etish va o‘tkazish.',
  },
  {
    icon: 'chart',
    title: 'Konsalting va biznes-reja',
    text: 'Boshqaruv masalalari bo‘yicha konsalting va biznes-reja tayyorlash.',
  },
  {
    icon: 'megaphone',
    title: 'Marketing va reklama',
    text: 'Marketing tadqiqotlari, reklama va turistik mahsulotni raqamli targ‘ib qilish.',
  },
  {
    icon: 'code',
    title: 'IT va raqamli platformalar',
    text: 'Turizm platformalari, web-saytlar va mobil ilovalar.',
  },
  {
    icon: 'cap',
    title: 'Ta’lim va kadrlar',
    text: 'Kurslar, treninglar, seminarlar; gid, ekskursovod va turizm menejerlarini tayyorlash.',
  },
  {
    icon: 'book',
    title: 'Nashriyot va kontent',
    text: 'Yo‘lnomalar, bukletlar, xaritalar hamda foto va video kontent.',
  },
  {
    icon: 'search',
    title: 'Ilmiy-tadqiqot',
    text: 'Turizm va mehmondo‘stlik sohasida ilmiy-tadqiqot va tajriba-konstruktorlik ishlari.',
  },
]
