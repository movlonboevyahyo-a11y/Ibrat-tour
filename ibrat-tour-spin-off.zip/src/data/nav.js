export const NAV_ITEMS = [
  { id: 'biz-haqimizda', label: 'Biz haqimizda' },
  { id: 'xizmatlar', label: 'Xizmatlar' },
  { id: 'yonalishlar', label: 'Yo‘nalishlar' },
  { id: 'talabalar', label: 'Talabalar' },
  { id: 'raqamli-turizm', label: 'Digital Tourism' },
  { id: 'hamkorlik', label: 'Hamkorlik' },
  { id: 'yangiliklar', label: 'Yangiliklar' },
  { id: 'faq', label: 'FAQ' },
  { id: 'aloqa', label: 'Aloqa' },
]

// Sahifadagi barcha bo‘lim id lari (DOM tartibida)
export const SECTION_IDS = [
  'bosh-sahifa',
  'biz-haqimizda',
  'xizmatlar',
  'yonalishlar',
  'talabalar',
  'raqamli-turizm',
  'hamkorlik',
  'yangiliklar',
  'faq',
  'rasmiy-hujjat',
  'aloqa',
]
