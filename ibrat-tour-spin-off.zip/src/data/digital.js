export const DIGITAL_ITEMS = [
  { icon: 'globe', title: 'Web platformalar', text: 'Turizm platformalari va web-saytlarni ishlab chiqish.' },
  { icon: 'phone', title: 'Mobil ilovalar', text: 'Sayohatchilar uchun mobil ilovalarni ishlab chiqish.' },
  { icon: 'headphones', title: 'Audiogid', text: 'Audiogid kontentini ishlab chiqish va tarqatish.' },
  { icon: 'compass', title: 'Elektron gid', text: 'Elektron gid xizmatini yaratish va tarqatish.' },
  { icon: 'map', title: 'Raqamli ekskursiyalar', text: 'Raqamli ekskursiya kontentini ishlab chiqish.' },
  { icon: 'camera', title: 'Turistik kontent', text: 'Foto va video xizmatlari, turistik kontent yaratish.' },
]

export const DIGITAL_EXTRAS = [
  'Ma’lumotlarni qayta ishlash va hosting',
  'Turistik mahsulotni raqamli targ‘ib qilish',
  'Onlayn savdo faoliyati',
]
