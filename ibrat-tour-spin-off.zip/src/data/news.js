// Real yangiliklar hozircha yo‘q — barcha kartochkalar DEMO.
export const NEWS = [
  {
    id: 'n1',
    tag: 'E’lonlar',
    title: 'Yangilik sarlavhasi namunasi',
    excerpt: 'Jamiyat faoliyati haqidagi rasmiy e’lonlar uchun ajratilgan joy.',
    demo: true,
  },
  {
    id: 'n2',
    tag: 'Yo‘nalishlar',
    title: 'Yangi marshrut haqida maqola namunasi',
    excerpt: 'Marshrutlar haqidagi maqolalar shu bo‘limda e’lon qilinadi.',
    demo: true,
  },
  {
    id: 'n3',
    tag: 'Talabalar',
    title: 'Talabalar loyihasi haqida hisobot namunasi',
    excerpt: 'Talabalar ishtirokidagi loyihalar haqidagi hisobotlar uchun joy.',
    demo: true,
  },
]
