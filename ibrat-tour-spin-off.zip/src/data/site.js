// Saytdagi barcha rasmiy ma’lumotlar 3 sentabr 2026-yildagi 64-F/B-sonli buyruqqa (PDF) asoslangan.
// Hujjatda bo‘lmagan ma’lumotlar bo‘sh qoldirilgan va saytda “Ma’lumot kiritilmagan” deb ko‘rsatiladi.

export const NOT_PROVIDED = 'Ma’lumot hozircha kiritilmagan'
export const NOT_ENTERED = 'Ma’lumot kiritilmagan'

export const SITE = {
  name: 'IBRAT TOUR SPIN-OFF',
  legalName: '“IBRAT TOUR SPIN-OFF” MCHJ',
  tagline: 'Turizm, innovatsiya va zamonaviy sayohat imkoniyatlari',
  founder: 'Is’hoqxon Ibrat nomidagi Namangan davlat chet tillari instituti',
}

export const OFFICIAL = {
  docType: 'Buyruq',
  number: '64-F/B',
  dateLabel: '3 sentabr 2026-yil',
  place: 'To‘raqo‘rg‘on shahri',
  title: '“IBRAT TOUR SPIN-OFF” MCHJ tashkil etish to‘g‘risida',
  ministry:
    'O‘zbekiston Respublikasi Maktabgacha va maktab ta’limi vazirligi huzuridagi Ixtisoslashtirilgan ta’lim muassasalari agentligi',
  issuer: 'Is’hoqxon Ibrat nomidagi Namangan davlat chet tillari instituti rektori',
  signedBy: 'R. Karimov',
  legalForm: 'Mas’uliyati cheklangan jamiyat (MCHJ)',
  basis: 'O‘zbekiston Respublikasi Prezidentining 2026-yil 4-apreldagi PF–54-son Farmoni',
  basisTitle:
    '“Mamlakatda yangi ishlanmalar asosida ishlab chiqarishni tashkil etish tizimini joriy qilish hamda ilm-fanni qo‘llab-quvvatlashning qo‘shimcha chora-tadbirlari to‘g‘risida”',
  code: 'QG64919575',
  verification: 'IJRO.GOV.UZ tizimi orqali ERI bilan tasdiqlangan',
  // public/docs/ papkasidagi fayl (nisbiy yo‘l — GitHub Pages va Netlify da bir xil ishlaydi)
  pdfUrl: 'docs/buyruq-64-F-B.pdf',
  pdfName: 'buyruq-64-F-B.pdf',
}

// Buyruq bandlarining qisqacha mazmuni
export const OFFICIAL_POINTS = [
  {
    n: '1',
    text: 'Institut tasarrufida “IBRAT TOUR SPIN-OFF” mas’uliyati cheklangan jamiyati belgilangan tartibda tashkil etiladi.',
  },
  {
    n: '2',
    text: 'Jamiyat Nizomi davlat ro‘yxatidan o‘tkazish uchun asos sifatida qabul qilinadi va zarur hujjatlar rasmiylashtiriladi.',
  },
  {
    n: '3',
    text: 'Jamiyatning asosiy maqsadi va faoliyat yo‘nalishlari belgilanadi — saytdagi xizmatlar aynan shu bandga tayanadi.',
  },
  {
    n: '4',
    text: 'Mas’ul rahbarlarga tashkiliy vazifalar yuklatiladi: institut ulushini shakllantirish (ustav fondining kamida 25 foizi institutning budjetdan tashqari mablag‘lari hisobidan), hujjatlarni tayyorlash, shart-sharoit yaratish, moliyaviy-xo‘jalik faoliyatini yo‘lga qo‘yish va monitoring.',
  },
  {
    n: '5',
    text: 'Tashkiliy, moliyaviy va huquqiy masalalar amaldagi qonunchilik hamda Jamiyat Nizomiga muvofiq hal etiladi.',
  },
  {
    n: '6',
    text: 'Buyruq ijrosini nazorat qilish rektor zimmasida qoldiriladi.',
  },
]

// Saytning qaysi bo‘limi buyruqning qaysi qismiga tayanishi
export const SOURCE_MAP = [
  { section: 'Biz haqimizda', source: '1-band (tashkil etish) va 3-band (maqsadlar)' },
  { section: 'Xizmatlar', source: '3-band (faoliyat yo‘nalishlari)' },
  {
    section: 'Turistik yo‘nalishlar',
    source:
      '3-band: marshrutlarni ishlab chiqish, sinovdan o‘tkazish va pasportlashtirish. Aniq marshrutlar hujjatda yo‘q — kartochkalar Demo.',
  },
  { section: 'Talabalar uchun', source: '3-band: talabalarning amaliy ko‘nikmalarini shakllantirish' },
  {
    section: 'Digital Tourism',
    source: '3-band: platformalar, mobil ilovalar, audiogid, elektron gid, raqamli kontent',
  },
  { section: 'Hamkorlik', source: '3-band: konsalting, MICE, marketing, turizm xizmatlari' },
  { section: 'Yangiliklar', source: 'Hujjatda bunday ma’lumot yo‘q — Demo' },
  { section: 'Aloqa', source: 'Tashkilot tomonidan taqdim etilgan (hujjatda yo‘q)' },
]

// Aloqa ma’lumotlari. Yangilash kerak bo‘lsa, shu yerni o‘zgartiring —
// saytdagi tugmalar va havolalar avtomatik yoqiladi/yangilanadi.
export const CONTACT = {
  phone: '+998 93 377 56 06',
  email: 'davronbekolimov351@gmail.com',
  address: 'Namangan davlat chet tillari instituti',
  socials: [
    { name: 'Telegram', url: 'https://t.me/ibrat_tour' },
    { name: 'Instagram', url: 'https://instagram.com/ibrat_tour' },
  ],
}

// Aloqa formasidagi mavzular (bo‘limlardan formani oldindan to‘ldirish uchun ham ishlatiladi)
export const TOPICS = {
  partnership: 'Hamkorlik',
  services: 'Xizmatlar bo‘yicha savol',
  students: 'Talabalar uchun yo‘nalishlar',
  routes: 'Turistik yo‘nalishlar',
  other: 'Boshqa',
}
export const TOPIC_LIST = Object.values(TOPICS)
