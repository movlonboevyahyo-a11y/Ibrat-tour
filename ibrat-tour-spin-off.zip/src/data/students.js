export const STUDENT_DIRECTIONS = [
  {
    icon: 'briefcase',
    title: 'Amaliy tajriba',
    text: 'Talabalarning amaliy ko‘nikmalarini shakllantirish — Jamiyatning buyruqda belgilangan maqsadlaridan biri.',
  },
  {
    icon: 'map',
    title: 'Turizm loyihalari',
    text: 'Turistik mahsulot, marshrut va ekskursiya loyihalari yo‘nalishida ko‘nikma hosil qilish.',
  },
  {
    icon: 'languages',
    title: 'Gidlik va tarjimonlik',
    text: 'Gid, gid-tarjimon va ekskursovod hamda tarjimonlik va til ko‘magi yo‘nalishlari.',
  },
  {
    icon: 'camera',
    title: 'Turistik kontent yaratish',
    text: 'Foto va video kontent, yo‘lnomalar, bukletlar va xaritalar tayyorlash yo‘nalishi.',
  },
  {
    icon: 'code',
    title: 'IT va raqamli turizm',
    text: 'Turizm platformalari, web-saytlar, mobil ilovalar, audiogid va elektron gid yo‘nalishi.',
  },
  {
    icon: 'chart',
    title: 'Marketing',
    text: 'Marketing tadqiqotlari, jamoatchilik fikrini o‘rganish va raqamli targ‘ibot yo‘nalishi.',
  },
]
