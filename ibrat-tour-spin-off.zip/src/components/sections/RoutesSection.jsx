import { useCallback, useState } from 'react'
import Section from '../ui/Section.jsx'
import SourceTag from '../ui/SourceTag.jsx'
import Badge from '../ui/Badge.jsx'
import Button from '../ui/Button.jsx'
import Modal from '../ui/Modal.jsx'
import RouteArt from '../ui/RouteArt.jsx'
import { ROUTES } from '../../data/routes.js'
import { NOT_PROVIDED, TOPICS } from '../../data/site.js'
import { emit } from '../../lib/bus.js'
import { scrollToSection } from '../../lib/scroll.js'

export default function RoutesSection() {
  const [selected, setSelected] = useState(null)
  const close = useCallback(() => setSelected(null), [])

  const askAbout = (route) => {
    emit('contact:prefill', {
      topic: TOPICS.routes,
      message: `“${route.title}” (Demo) yo‘nalishi bo‘yicha so‘rovim: `,
    })
    close()
    window.setTimeout(() => scrollToSection('aloqa'), 80)
  }

  return (
    <Section
      id="yonalishlar"
      title="Turistik yo‘nalishlar"
      lead="Buyruqda aniq marshrutlar keltirilmagan, shuning uchun quyidagi kartochkalar — Demo. Ular tayyorlanadigan yo‘nalish turlarini ko‘rsatadi."
      aside={<SourceTag>Manba: buyruq, 3-band</SourceTag>}
    >
      <ul className="routes reveal">
        {ROUTES.map((route) => (
          <li key={route.id}>
            <article className="route-card">
              <div className="route-card__art">
                {route.photo ? (
                  <img className="route-card__photo" src={route.photo} alt={route.photoAlt || ''} loading="lazy" />
                ) : (
                  <RouteArt variant={route.art} />
                )}
                {route.demo ? (
                  <span className="route-card__badge">
                    <Badge>Demo</Badge>
                  </span>
                ) : null}
              </div>
              <div className="route-card__body">
                <p className="route-card__kind">{route.kind}</p>
                <h3 className="route-card__title">{route.title}</h3>
                <p className="route-card__text">{route.short}</p>
                <Button variant="outline" size="sm" onClick={() => setSelected(route)} aria-label={`Batafsil: ${route.title}`}>
                  Batafsil
                </Button>
              </div>
            </article>
          </li>
        ))}
      </ul>

      <Modal open={Boolean(selected)} onClose={close} titleId="route-modal-title">
        {selected ? (
          <div className="route-modal">
            <div className="route-modal__art">
              {selected.photo ? (
                <img className="route-modal__photo" src={selected.photo} alt={selected.photoAlt || ''} />
              ) : (
                <RouteArt variant={selected.art} />
              )}
            </div>
            <div className="route-modal__body">
              <div className="route-modal__meta">
                <Badge>Demo</Badge>
                <span>{selected.kind}</span>
              </div>
              <h3 id="route-modal-title" className="route-modal__title">
                {selected.title}
              </h3>
              <p>{selected.long}</p>
              <dl className="detail-list">
                <div>
                  <dt>Marshrut nuqtalari</dt>
                  <dd className="missing">{NOT_PROVIDED}</dd>
                </div>
                <div>
                  <dt>Davomiyligi</dt>
                  <dd className="missing">{NOT_PROVIDED}</dd>
                </div>
                <div>
                  <dt>Narxi</dt>
                  {selected.price ? <dd>{selected.price}</dd> : <dd className="missing">{NOT_PROVIDED}</dd>}
                </div>
              </dl>
              <p className="modal__note">Bu kartochka — Demo. Real marshrutlar tasdiqlangach, shu yerda e’lon qilinadi.</p>
              <div className="modal__actions">
                <Button variant="primary" onClick={() => askAbout(selected)}>
                  So‘rov qoldirish
                </Button>
                <Button variant="outline" onClick={close}>
                  Yopish
                </Button>
              </div>
            </div>
          </div>
        ) : null}
      </Modal>
    </Section>
  )
}
