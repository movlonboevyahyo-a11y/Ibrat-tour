import Section from '../ui/Section.jsx'
import Button from '../ui/Button.jsx'
import Icon from '../ui/Icon.jsx'
import { OFFICIAL, OFFICIAL_POINTS, SOURCE_MAP } from '../../data/site.js'

export default function OfficialDocument() {
  return (
    <Section
      id="rasmiy-hujjat"
      title="Rasmiy hujjat"
      lead="Saytdagi barcha rasmiy ma’lumotlar quyidagi buyruqdan olingan. Asl nusxa PDF ko‘rinishida ochiladi."
    >
      <div className="doc">
        <article className="doc-paper reveal" aria-label="Hujjat rekvizitlari">
          <p className="doc-paper__org">{OFFICIAL.ministry}</p>
          <p className="doc-paper__type">
            {OFFICIAL.docType} № {OFFICIAL.number}
          </p>
          <h3 className="doc-paper__title">
            <span className="nowrap">“IBRAT TOUR SPIN-OFF”</span> MCHJ tashkil etish to‘g‘risida
          </h3>

          <dl className="doc-paper__list">
            <div>
              <dt>Sana va joy</dt>
              <dd>
                {OFFICIAL.dateLabel}, {OFFICIAL.place}
              </dd>
            </div>
            <div>
              <dt>Chiqargan</dt>
              <dd>{OFFICIAL.issuer}</dd>
            </div>
            <div>
              <dt>Imzolagan</dt>
              <dd>Rektor {OFFICIAL.signedBy}</dd>
            </div>
            <div>
              <dt>Asos</dt>
              <dd>
                {OFFICIAL.basis}: {OFFICIAL.basisTitle}
              </dd>
            </div>
            <div>
              <dt>Hujjat kodi</dt>
              <dd>{OFFICIAL.code}</dd>
            </div>
            <div>
              <dt>Tasdiqlash</dt>
              <dd>{OFFICIAL.verification}</dd>
            </div>
          </dl>

          <div className="doc-paper__actions">
            <Button href={OFFICIAL.pdfUrl} external variant="primary" icon="external">
              PDF hujjatni ochish
            </Button>
            <Button href={OFFICIAL.pdfUrl} download={OFFICIAL.pdfName} variant="outline" icon="download">
              Yuklab olish
            </Button>
          </div>
        </article>

        <div className="doc-side reveal">
          <section aria-labelledby="doc-points-title">
            <h3 id="doc-points-title" className="doc-side__title">
              Buyruq bandlari
            </h3>
            <ol className="doc-points">
              {OFFICIAL_POINTS.map((point) => (
                <li key={point.n}>
                  <span className="doc-points__n">{point.n}</span>
                  <p>{point.text}</p>
                </li>
              ))}
            </ol>
          </section>

          <section aria-labelledby="doc-map-title">
            <h3 id="doc-map-title" className="doc-side__title">
              Qaysi bo‘lim qayerdan olingan
            </h3>
            <table className="source-table">
              <thead>
                <tr>
                  <th scope="col">Bo‘lim</th>
                  <th scope="col">Manba</th>
                </tr>
              </thead>
              <tbody>
                {SOURCE_MAP.map((row) => (
                  <tr key={row.section}>
                    <th scope="row">{row.section}</th>
                    <td>{row.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </div>
      </div>
      <p className="doc-note">
        <Icon name="shield" size={18} />
        <span>Hujjat nusxasi saytga o‘zgartirishsiz qo‘shilgan. Ushbu sayt rasmiy hujjatni almashtirmaydi.</span>
      </p>
    </Section>
  )
}
