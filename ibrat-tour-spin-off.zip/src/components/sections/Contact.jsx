import { useEffect, useState } from 'react'
import Section from '../ui/Section.jsx'
import Icon from '../ui/Icon.jsx'
import Button from '../ui/Button.jsx'
import { CONTACT, NOT_ENTERED, SITE, TOPIC_LIST, TOPICS } from '../../data/site.js'
import { on } from '../../lib/bus.js'
import { copyText } from '../../lib/clipboard.js'

function Missing() {
  return <span className="missing">{NOT_ENTERED}</span>
}

function buildMessage(form) {
  return [
    'Assalomu alaykum!',
    `Mavzu: ${form.topic}`,
    `Ism: ${form.name}`,
    `Tashkilot: ${form.org || 'ko‘rsatilmagan'}`,
    `Xabar: ${form.message}`,
    '',
    `(${SITE.name} saytidan tayyorlangan so‘rov)`,
  ].join('\n')
}

export default function Contact() {
  const [form, setForm] = useState({ name: '', org: '', topic: TOPICS.partnership, message: '' })
  const [draft, setDraft] = useState('')
  const [status, setStatus] = useState('')

  useEffect(
    () =>
      on('contact:prefill', (detail) => {
        const { topic, message } = detail || {}
        setForm((current) => ({
          ...current,
          topic: TOPIC_LIST.includes(topic) ? topic : current.topic,
          message: typeof message === 'string' ? message : current.message,
        }))
        setDraft('')
        setStatus('')
      }),
    [],
  )

  const update = (key) => (event) => {
    const { value } = event.target
    setForm((current) => ({ ...current, [key]: value }))
  }

  const submit = (event) => {
    event.preventDefault()
    setDraft(buildMessage(form))
    setStatus('')
  }

  const copy = async () => {
    const ok = await copyText(draft)
    setStatus(ok ? 'Matn nusxalandi.' : 'Nusxalab bo‘lmadi. Matnni qo‘lda belgilab nusxalang.')
  }

  const mailto = CONTACT.email
    ? `mailto:${CONTACT.email}?subject=${encodeURIComponent(`${SITE.name}: ${form.topic}`)}&body=${encodeURIComponent(draft)}`
    : ''

  return (
    <Section
      id="aloqa"
      title="Aloqa"
      lead="Savol va takliflaringiz bo‘lsa, quyidagi aloqa vositalari orqali murojaat qiling."
    >
      <div className="contact">
        <div className="contact__info reveal">
          <dl className="contact-list">
            <div className="contact-list__row">
              <dt>
                <Icon name="call" size={18} /> Telefon
              </dt>
              <dd>
                {CONTACT.phone ? (
                  <a className="text-link" href={`tel:${CONTACT.phone.replace(/[^\d+]/g, '')}`}>
                    {CONTACT.phone}
                  </a>
                ) : (
                  <Missing />
                )}
              </dd>
            </div>
            <div className="contact-list__row">
              <dt>
                <Icon name="mail" size={18} /> Email
              </dt>
              <dd>
                {CONTACT.email ? (
                  <a className="text-link" href={`mailto:${CONTACT.email}`}>
                    {CONTACT.email}
                  </a>
                ) : (
                  <Missing />
                )}
              </dd>
            </div>
            <div className="contact-list__row">
              <dt>
                <Icon name="pin" size={18} /> Manzil
              </dt>
              <dd>{CONTACT.address ? CONTACT.address : <Missing />}</dd>
            </div>
            <div className="contact-list__row">
              <dt>
                <Icon name="share" size={18} /> Ijtimoiy tarmoqlar
              </dt>
              <dd>
                {CONTACT.socials.length ? (
                  <ul className="contact-socials">
                    {CONTACT.socials.map((social) => (
                      <li key={social.url}>
                        <a className="text-link" href={social.url} target="_blank" rel="noopener noreferrer">
                          {social.name}
                        </a>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <Missing />
                )}
              </dd>
            </div>
          </dl>
          <p className="contact__founder">Tashkil etuvchi muassasa: {SITE.founder}.</p>
        </div>

        <div className="contact__form reveal">
          <h3 className="contact__form-title">So‘rov qoldirish</h3>
          <p className="contact__form-lead">
            Ma’lumotlarni to‘ldiring — tayyor xabar matni hosil bo‘ladi. Uni nusxalab, aloqa ma’lumotlari e’lon
            qilingach yuborishingiz mumkin.
          </p>

          <form onSubmit={submit}>
            <div className="field">
              <label htmlFor="cf-name">Ismingiz</label>
              <input id="cf-name" name="name" type="text" autoComplete="name" required value={form.name} onChange={update('name')} />
            </div>
            <div className="field">
              <label htmlFor="cf-org">Tashkilot (ixtiyoriy)</label>
              <input id="cf-org" name="org" type="text" autoComplete="organization" value={form.org} onChange={update('org')} />
            </div>
            <div className="field">
              <label htmlFor="cf-topic">Mavzu</label>
              <select id="cf-topic" name="topic" value={form.topic} onChange={update('topic')}>
                {TOPIC_LIST.map((topic) => (
                  <option key={topic} value={topic}>
                    {topic}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="cf-message">Xabar</label>
              <textarea id="cf-message" name="message" rows={4} required value={form.message} onChange={update('message')} />
            </div>
            <button type="submit" className="btn btn--primary btn--md">
              <span>Xabar matnini tayyorlash</span>
            </button>
          </form>

          {draft ? (
            <div className="draft" role="group" aria-labelledby="draft-title">
              <h4 id="draft-title" className="draft__title">
                Tayyor matn
              </h4>
              <textarea className="draft__text" readOnly rows={7} value={draft} aria-label="Tayyor xabar matni" />
              <div className="draft__actions">
                <Button variant="outline" icon="copy" onClick={copy}>
                  Nusxalash
                </Button>
                {mailto ? (
                  <Button href={mailto} variant="primary" icon="mail">
                    Email orqali yuborish
                  </Button>
                ) : null}
              </div>
              <p className="draft__status" role="status" aria-live="polite">
                {status}
              </p>
            </div>
          ) : null}
        </div>
      </div>
    </Section>
  )
}
