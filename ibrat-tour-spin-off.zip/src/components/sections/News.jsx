import { useCallback, useState } from 'react'
import Section from '../ui/Section.jsx'
import Badge from '../ui/Badge.jsx'
import Button from '../ui/Button.jsx'
import Modal from '../ui/Modal.jsx'
import { NEWS } from '../../data/news.js'
import { NOT_PROVIDED } from '../../data/site.js'

export default function News() {
  const [selected, setSelected] = useState(null)
  const close = useCallback(() => setSelected(null), [])

  return (
    <Section
      id="yangiliklar"
      title="Yangiliklar"
      lead="Real yangiliklar hozircha e’lon qilinmagan. Quyidagi kartochkalar — Demo, kelajakdagi yangiliklar ko‘rinishi namunasi."
      aside={<Badge>Demo kontent</Badge>}
    >
      <ul className="news-grid reveal">
        {NEWS.map((item) => (
          <li key={item.id}>
            <article className="news-card">
              <div className="news-card__top">
                {item.demo ? <Badge>Demo</Badge> : null}
                <span className="news-card__tag">{item.tag}</span>
              </div>
              <h3 className="news-card__title">{item.title}</h3>
              <p className="news-card__text">{item.excerpt}</p>
              <button
                type="button"
                className="text-btn"
                onClick={() => setSelected(item)}
                aria-label={`Batafsil: ${item.title}`}
              >
                Batafsil
              </button>
            </article>
          </li>
        ))}
      </ul>

      <Modal open={Boolean(selected)} onClose={close} titleId="news-modal-title">
        {selected ? (
          <div className="simple-modal">
            <div className="route-modal__meta">
              <Badge>Demo</Badge>
              <span>{selected.tag}</span>
            </div>
            <h3 id="news-modal-title" className="route-modal__title">
              {selected.title}
            </h3>
            <p>Bu — demo kontent. Real yangilik e’lon qilinganda uning matni, sanasi va rasmi shu yerda ko‘rsatiladi.</p>
            <dl className="detail-list">
              <div>
                <dt>Sana</dt>
                <dd className="missing">{NOT_PROVIDED}</dd>
              </div>
              <div>
                <dt>Muallif</dt>
                <dd className="missing">{NOT_PROVIDED}</dd>
              </div>
            </dl>
            <div className="modal__actions">
              <Button variant="outline" onClick={close}>
                Yopish
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>
    </Section>
  )
}
