import { useEffect, useRef, useState } from 'react'
import Section from '../ui/Section.jsx'
import SourceTag from '../ui/SourceTag.jsx'
import Icon from '../ui/Icon.jsx'
import Button from '../ui/Button.jsx'
import { SERVICE_CATEGORIES } from '../../data/services.js'
import { NOT_PROVIDED, TOPICS } from '../../data/site.js'
import { emit, on } from '../../lib/bus.js'

export default function Services() {
  const [activeId, setActiveId] = useState(SERVICE_CATEGORIES[0].id)
  const tabRefs = useRef([])
  const count = SERVICE_CATEGORIES.length

  useEffect(
    () =>
      on('service:select', (id) => {
        if (SERVICE_CATEGORIES.some((category) => category.id === id)) setActiveId(id)
      }),
    [],
  )

  const active = SERVICE_CATEGORIES.find((category) => category.id === activeId) || SERVICE_CATEGORIES[0]

  const onKeyDown = (event) => {
    const index = SERVICE_CATEGORIES.findIndex((category) => category.id === activeId)
    let next = index
    if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = (index + 1) % count
    else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') next = (index - 1 + count) % count
    else if (event.key === 'Home') next = 0
    else if (event.key === 'End') next = count - 1
    else return
    event.preventDefault()
    setActiveId(SERVICE_CATEGORIES[next].id)
    const button = tabRefs.current[next]
    if (button) button.focus()
  }

  return (
    <Section
      id="xizmatlar"
      tone="alt"
      title="Xizmatlar"
      lead="Buyruqda belgilangan faoliyat yo‘nalishlari sakkizta guruhga ajratilgan. Guruhni tanlang."
      aside={<SourceTag>Manba: buyruq, 3-band</SourceTag>}
    >
      <div className="services reveal">
        <div className="services__tabs" role="tablist" aria-label="Xizmat guruhlari" aria-orientation="vertical" onKeyDown={onKeyDown}>
          {SERVICE_CATEGORIES.map((category, index) => {
            const selected = category.id === activeId
            return (
              <button
                key={category.id}
                ref={(node) => {
                  tabRefs.current[index] = node
                }}
                type="button"
                role="tab"
                id={`svc-tab-${category.id}`}
                aria-selected={selected}
                aria-controls="svc-panel"
                tabIndex={selected ? 0 : -1}
                className={`svc-tab${selected ? ' is-active' : ''}`}
                onClick={() => setActiveId(category.id)}
              >
                <span className="svc-tab__icon">
                  <Icon name={category.icon} size={20} />
                </span>
                <span className="svc-tab__title">{category.title}</span>
                <span className="svc-tab__count">{category.items.length}</span>
              </button>
            )
          })}
        </div>

        <div
          key={active.id}
          className="services__panel"
          role="tabpanel"
          id="svc-panel"
          aria-labelledby={`svc-tab-${active.id}`}
          tabIndex={0}
        >
          <div className="services__panel-head">
            <span className="services__panel-icon">
              <Icon name={active.icon} size={28} />
            </span>
            <div>
              <h3 className="services__panel-title">{active.title}</h3>
              <p className="services__panel-blurb">{active.blurb}</p>
            </div>
          </div>

          <ul className="services__items">
            {active.items.map((item) => (
              <li key={item}>
                <Icon name="check" size={18} className="services__check" />
                <span>{item}</span>
              </li>
            ))}
          </ul>

          <div className="services__foot">
            <p>
              Narxlar va buyurtma tartibi: <span className="missing">{NOT_PROVIDED}</span>
            </p>
            <Button
              href="#aloqa"
              variant="outline"
              onClick={() =>
                emit('contact:prefill', {
                  topic: TOPICS.services,
                  message: `“${active.title}” yo‘nalishi bo‘yicha savolim: `,
                })
              }
            >
              Savol yuborish
            </Button>
          </div>
        </div>
      </div>
    </Section>
  )
}
