import Button from '../ui/Button.jsx'
import { OFFICIAL, SITE } from '../../data/site.js'

export default function Hero() {
  return (
    <section id="bosh-sahifa" className="hero" aria-labelledby="bosh-sahifa-title">
      <div className="hero__backdrop" aria-hidden="true">
        <svg className="hero__ridge" viewBox="0 0 1440 320" preserveAspectRatio="none" focusable="false">
          <path
            className="hero__ridge-back"
            d="M0 220L140 150L250 205L390 110L520 200L640 140L780 215L910 120L1050 205L1180 150L1310 210L1440 160V320H0Z"
          />
          <path
            className="hero__ridge-front"
            d="M0 270L120 225L230 262L380 200L520 262L680 214L840 268L1000 208L1160 264L1300 226L1440 262V320H0Z"
          />
        </svg>
      </div>

      <div className="container hero__grid">
        <div className="hero__copy">
          <p className="hero__kicker">{SITE.founder} tasarrufida</p>
          <h1 id="bosh-sahifa-title" className="hero__title">
            <span className="hero__title-line">IBRAT TOUR</span> <span className="hero__title-line">SPIN-OFF</span>
          </h1>
          <p className="hero__lead">{SITE.tagline}</p>

          <div className="hero__actions">
            <Button href="#xizmatlar" variant="primary" size="lg">
              Xizmatlarni ko‘rish
            </Button>
            <Button href="#biz-haqimizda" variant="glass" size="lg">
              Biz haqimizda
            </Button>
            <Button href="#aloqa" variant="text-light" size="lg">
              Bog‘lanish
            </Button>
          </div>

          <a className="hero__doc" href="#rasmiy-hujjat">
            <span className="hero__doc-label">Rasmiy asos</span>
            <span className="hero__doc-text">
              {OFFICIAL.docType} № {OFFICIAL.number}, {OFFICIAL.dateLabel}
            </span>
          </a>
        </div>

        <div className="hero__art" aria-hidden="true">
          <div className="hero__logo-stage">
            <span className="hero__logo-glow" />
            <img className="hero__logo-img" src="/logo.png" alt="" width={520} height={520} />
          </div>
          <span className="hero__chip hero__chip--a">Ilmiy-innovatsion ishlanmalar</span>
          <span className="hero__chip hero__chip--b">Turizm xizmatlari</span>
          <span className="hero__chip hero__chip--c">Talabalar amaliyoti</span>
        </div>
      </div>
    </section>
  )
}
