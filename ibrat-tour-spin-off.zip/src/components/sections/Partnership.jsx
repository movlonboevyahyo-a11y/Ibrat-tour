import Section from '../ui/Section.jsx'
import SourceTag from '../ui/SourceTag.jsx'
import Icon from '../ui/Icon.jsx'
import Button from '../ui/Button.jsx'
import { PARTNERSHIP_AREAS } from '../../data/partnership.js'
import { TOPICS } from '../../data/site.js'
import { emit } from '../../lib/bus.js'

export default function Partnership() {
  return (
    <Section
      id="hamkorlik"
      tone="alt"
      title="Biznes va hamkorlik"
      lead="Turizm, tadbirlar, marketing va IT yo‘nalishlarida hamkorlik qilmoqchi bo‘lgan tashkilotlar uchun."
      aside={<SourceTag>Manba: buyruq, 3-band</SourceTag>}
    >
      <ul className="partner-list reveal">
        {PARTNERSHIP_AREAS.map((area) => (
          <li key={area.title} className="partner-row">
            <span className="partner-row__icon">
              <Icon name={area.icon} size={22} />
            </span>
            <div className="partner-row__body">
              <h3 className="partner-row__title">{area.title}</h3>
              <p className="partner-row__text">{area.text}</p>
            </div>
            <a
              className="text-link partner-row__link"
              href="#aloqa"
              aria-label={`Yozish: ${area.title}`}
              onClick={() =>
                emit('contact:prefill', {
                  topic: TOPICS.partnership,
                  message: `Hamkorlik yo‘nalishi: ${area.title}. `,
                })
              }
            >
              Yozish
            </a>
          </li>
        ))}
      </ul>

      <div className="cta-band reveal">
        <div>
          <h3 className="cta-band__title">Hamkorlik qilmoqchimisiz?</h3>
          <p className="cta-band__text">Hamkorlik shartlari va narxlar admin orqali kelishiladi. So‘rovingizni qoldiring.</p>
        </div>
        <Button
          href="#aloqa"
          variant="primary"
          size="lg"
          onClick={() => emit('contact:prefill', { topic: TOPICS.partnership })}
        >
          Hamkorlik qilish
        </Button>
      </div>
    </Section>
  )
}
