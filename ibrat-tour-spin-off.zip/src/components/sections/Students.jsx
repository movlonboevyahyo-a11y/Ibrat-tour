import Section from '../ui/Section.jsx'
import SourceTag from '../ui/SourceTag.jsx'
import Icon from '../ui/Icon.jsx'
import Button from '../ui/Button.jsx'
import { STUDENT_DIRECTIONS } from '../../data/students.js'
import { NOT_PROVIDED, TOPICS } from '../../data/site.js'
import { emit } from '../../lib/bus.js'

export default function Students() {
  return (
    <Section
      id="talabalar"
      title="Talabalar uchun"
      lead="Jamiyatning maqsadlaridan biri — talabalarning amaliy ko‘nikmalarini shakllantirish. Quyida shu maqsadga mos yo‘nalishlar ko‘rsatilgan."
      aside={<SourceTag>Manba: buyruq, 3-band</SourceTag>}
    >
      <div className="students">
        <ul className="students__list reveal">
          {STUDENT_DIRECTIONS.map((item) => (
            <li key={item.title} className="student-row">
              <span className="student-row__icon">
                <Icon name={item.icon} size={22} />
              </span>
              <div>
                <h3 className="student-row__title">{item.title}</h3>
                <p className="student-row__text">{item.text}</p>
              </div>
            </li>
          ))}
        </ul>

        <aside className="notice reveal" aria-label="Muhim eslatma">
          <h3 className="notice__title">Hozircha e’lon qilinmagan</h3>
          <p>
            Buyruqda ishga qabul qilish, ish haqi, stipendiya yoki kafolatlangan amaliyot haqida ma’lumot yo‘q.
            Shuning uchun saytda bunday va’dalar berilmaydi.
          </p>
          <dl className="detail-list">
            <div>
              <dt>Qabul tartibi</dt>
              <dd className="missing">{NOT_PROVIDED}</dd>
            </div>
            <div>
              <dt>Ish haqi va stipendiya</dt>
              <dd className="missing">{NOT_PROVIDED}</dd>
            </div>
            <div>
              <dt>Amaliyot shartlari</dt>
              <dd className="missing">{NOT_PROVIDED}</dd>
            </div>
          </dl>
          <Button
            href="#aloqa"
            variant="outline"
            onClick={() =>
              emit('contact:prefill', {
                topic: TOPICS.students,
                message: 'Talabalar uchun yo‘nalishlar bo‘yicha savolim: ',
              })
            }
          >
            Savol yuborish
          </Button>
        </aside>
      </div>
    </Section>
  )
}
