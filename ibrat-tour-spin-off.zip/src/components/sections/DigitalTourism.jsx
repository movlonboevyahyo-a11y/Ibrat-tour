import Section from '../ui/Section.jsx'
import SourceTag from '../ui/SourceTag.jsx'
import Badge from '../ui/Badge.jsx'
import Icon from '../ui/Icon.jsx'
import { DIGITAL_EXTRAS, DIGITAL_ITEMS } from '../../data/digital.js'

// Faqat ko‘rgazma uchun: bosiladigan elementlar yo‘q, ekran o‘qish dasturlaridan yashirilgan.
function PhoneMock() {
  return (
    <div className="phone" aria-hidden="true">
      <div className="phone__notch" />
      <div className="phone__screen">
        <div className="phone__top">
          <span className="phone__title">Elektron gid</span>
          <Badge>Demo</Badge>
        </div>
        <div className="phone__map">
          <svg viewBox="0 0 200 110" preserveAspectRatio="xMidYMid slice" focusable="false">
            <rect width="200" height="110" fill="#1b2c69" />
            <g stroke="#ffffff" strokeOpacity=".12" strokeWidth="1">
              <path d="M0 30H200M0 60H200M0 90H200M40 0V110M90 0V110M140 0V110M180 0V110" />
            </g>
            <path
              d="M22 88C50 40 90 96 118 54S170 30 182 22"
              fill="none"
              stroke="#f2b544"
              strokeWidth="2.5"
              strokeDasharray="2 6"
              strokeLinecap="round"
            />
            <circle cx="22" cy="88" r="5" fill="#f2b544" />
            <circle cx="118" cy="54" r="5" fill="#f2b544" />
            <circle cx="182" cy="22" r="6" fill="#c2334d" />
          </svg>
        </div>
        <div className="phone__player">
          <span className="phone__play">
            <svg viewBox="0 0 10 10" width="10" height="10" focusable="false">
              <path d="M2 1l7 4-7 4z" fill="currentColor" />
            </svg>
          </span>
          <span className="phone__track">
            <span className="phone__progress" />
          </span>
          <span className="phone__time">02:14</span>
        </div>
        <ol className="phone__stops">
          <li>Birinchi nuqta</li>
          <li>Ikkinchi nuqta</li>
          <li>Uchinchi nuqta</li>
        </ol>
      </div>
    </div>
  )
}

export default function DigitalTourism() {
  return (
    <Section
      id="raqamli-turizm"
      tone="dark"
      title="Digital Tourism"
      lead="Raqamli turizm: platformalar, ilovalar va kontent. Buyruqda belgilangan IT yo‘nalishlari."
      aside={<SourceTag>Manba: buyruq, 3-band</SourceTag>}
    >
      <div className="digital">
        <div className="digital__main reveal">
          <ul className="digital__grid">
            {DIGITAL_ITEMS.map((item) => (
              <li key={item.title} className="digital-item">
                <span className="digital-item__icon">
                  <Icon name={item.icon} size={22} />
                </span>
                <h3 className="digital-item__title">{item.title}</h3>
                <p className="digital-item__text">{item.text}</p>
              </li>
            ))}
          </ul>

          <ul className="digital__extras" aria-label="Qo‘shimcha raqamli yo‘nalishlar">
            {DIGITAL_EXTRAS.map((text) => (
              <li key={text}>
                <Icon name="check" size={16} />
                <span>{text}</span>
              </li>
            ))}
          </ul>
        </div>

        <figure className="digital__device reveal">
          <PhoneMock />
          <figcaption>Demo interfeys — real ilova emas.</figcaption>
        </figure>
      </div>
    </Section>
  )
}
