import { useState } from 'react'
import Section from '../ui/Section.jsx'
import Icon from '../ui/Icon.jsx'
import { FAQ } from '../../data/faq.js'

export default function Faq() {
  const [openIndex, setOpenIndex] = useState(0)

  return (
    <Section
      id="faq"
      tone="alt"
      title="Savol-javob"
      lead="Javoblar rasmiy hujjat (buyruq) mazmuniga asoslangan."
    >
      <div className="faq reveal">
        {FAQ.map((item, index) => {
          const isOpen = openIndex === index
          return (
            <div key={item.q} className={`faq__item${isOpen ? ' is-open' : ''}`}>
              <h3 className="faq__q">
                <button
                  type="button"
                  className="faq__button"
                  id={`faq-button-${index}`}
                  aria-expanded={isOpen}
                  aria-controls={`faq-panel-${index}`}
                  onClick={() => setOpenIndex(isOpen ? -1 : index)}
                >
                  <span>{item.q}</span>
                  <Icon name="chevron" size={20} className="faq__chevron" />
                </button>
              </h3>
              <div
                id={`faq-panel-${index}`}
                className="faq__panel"
                role="region"
                aria-labelledby={`faq-button-${index}`}
              >
                <div className="faq__panel-inner">
                  <p>{item.a}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </Section>
  )
}
