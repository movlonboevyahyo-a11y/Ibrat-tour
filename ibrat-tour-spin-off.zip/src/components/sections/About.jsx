import Section from '../ui/Section.jsx'
import SourceTag from '../ui/SourceTag.jsx'
import Icon from '../ui/Icon.jsx'
import { OFFICIAL, SITE } from '../../data/site.js'

const GOALS = [
  {
    icon: 'search',
    title: 'Ilmiy-innovatsion ishlanmalarni joriy etish',
    text: 'Institutning ilmiy-innovatsion ishlanmalarini turizm sohasida amaliyotga joriy etish.',
  },
  {
    icon: 'compass',
    title: 'Raqobatbardosh turistik mahsulot',
    text: 'Turizm xizmatlari bozorida raqobatbardosh mahsulot yaratish.',
  },
  {
    icon: 'cap',
    title: 'Amaliyot va ko‘nikma',
    text: 'Talabalarning amaliy ko‘nikmalarini shakllantirish.',
  },
  {
    icon: 'chart',
    title: 'Institut salohiyatidan foydalanish',
    text: 'Institutning ilmiy, innovatsion va ta’lim salohiyatidan samarali foydalanish hamda qo‘shimcha daromad manbalarini shakllantirish.',
  },
]

export default function About() {
  return (
    <Section
      id="biz-haqimizda"
      title="Biz haqimizda"
      lead="Institutning ilmiy va ta’lim salohiyatini turizm amaliyotiga olib chiqadigan spin-off korxona."
      aside={<SourceTag>Manba: buyruq, 1 va 3-bandlar</SourceTag>}
    >
      <div className="about">
        <div className="about__text reveal">
          <p>
            {SITE.legalName} — {SITE.founder} tasarrufida tashkil etish belgilangan, yangi ishlanmalarga
            asoslangan “Spin-off” korxona.
          </p>
          <p>
            Korxonani tashkil etishdan maqsad — institutning ilmiy, innovatsion va ta’lim salohiyatidan samarali
            foydalanish hamda qo‘shimcha daromad manbalarini shakllantirish. Turizm sohasida bu ilmiy-innovatsion
            ishlanmalarni amaliyotga joriy etish, raqobatbardosh turistik mahsulot yaratish va talabalarning amaliy
            ko‘nikmalarini shakllantirish demakdir.
          </p>
        </div>

        <aside className="fact-sheet reveal" aria-label="Buyruqning rasmiy ma’lumotlari">
          <h3 className="fact-sheet__title">Buyruqning rasmiy ma’lumotlari</h3>
          <dl className="fact-sheet__list">
            <div>
              <dt>Buyruq sanasi</dt>
              <dd>{OFFICIAL.dateLabel}</dd>
            </div>
            <div>
              <dt>Buyruq raqami</dt>
              <dd>{OFFICIAL.number}</dd>
            </div>
            <div>
              <dt>Tashkil etuvchi muassasa</dt>
              <dd>{SITE.founder}</dd>
            </div>
            <div>
              <dt>Tashkiliy-huquqiy shakl</dt>
              <dd>{OFFICIAL.legalForm}</dd>
            </div>
          </dl>
          <a className="text-link" href="#rasmiy-hujjat">
            Rasmiy hujjat haqida
          </a>
        </aside>
      </div>

      <div className="goals reveal">
        <h3 className="goals__title">Jamiyatning maqsadlari</h3>
        <ul className="goals__list">
          {GOALS.map((goal) => (
            <li key={goal.title} className="goal">
              <span className="goal__icon">
                <Icon name={goal.icon} size={22} />
              </span>
              <h4 className="goal__title">{goal.title}</h4>
              <p className="goal__text">{goal.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </Section>
  )
}
