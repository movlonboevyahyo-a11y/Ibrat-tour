import Icon from '../ui/Icon.jsx'
import { emit } from '../../lib/bus.js'

const ITEMS = [
  {
    icon: 'plane',
    title: 'Turizm xizmatlari',
    text: 'Turoperatorlik, turagentlik, ichki, kirish va chiqish turizmi.',
    href: '#xizmatlar',
    category: 'turizm',
  },
  {
    icon: 'languages',
    title: 'Gid va tarjimonlik',
    text: 'Gid, gid-tarjimon, ekskursovod hamda til ko‘magi xizmatlari.',
    href: '#xizmatlar',
    category: 'ekskursiya',
  },
  {
    icon: 'map',
    title: 'Turistik marshrutlar',
    text: 'Marshrutlarni ishlab chiqish, sinovdan o‘tkazish va pasportlashtirish.',
    href: '#yonalishlar',
  },
  {
    icon: 'phone',
    title: 'Raqamli turizm',
    text: 'Platformalar, mobil ilovalar, audiogid va elektron gid.',
    href: '#raqamli-turizm',
  },
]

export default function Highlights() {
  return (
    <section className="highlights" aria-label="Asosiy yo‘nalishlar">
      <div className="container">
        <ul className="highlights__grid">
          {ITEMS.map((item) => (
            <li key={item.title}>
              <a
                className="tile"
                href={item.href}
                onClick={() => {
                  if (item.category) emit('service:select', item.category)
                }}
              >
                <span className="tile__icon">
                  <Icon name={item.icon} size={26} />
                </span>
                <span className="tile__title">{item.title}</span>
                <span className="tile__text">{item.text}</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
