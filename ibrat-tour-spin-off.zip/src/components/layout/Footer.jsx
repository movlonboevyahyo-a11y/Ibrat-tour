import Logo from '../ui/Logo.jsx'
import Icon from '../ui/Icon.jsx'
import { NAV_ITEMS } from '../../data/nav.js'
import { OFFICIAL, SITE } from '../../data/site.js'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <a className="brand brand--footer" href="#bosh-sahifa" aria-label="Sahifa boshiga qaytish">
            <Logo size={44} />
            <span className="brand__text">
              <span className="brand__name">IBRAT TOUR</span>
              <span className="brand__sub">SPIN-OFF</span>
            </span>
          </a>
          <p className="footer__text">
            {SITE.founder} tasarrufida tashkil etish belgilangan turizm yo‘nalishidagi spin-off korxona.
          </p>
        </div>

        <nav className="footer__nav" aria-label="Sayt bo‘limlari">
          <h2 className="footer__title">Bo‘limlar</h2>
          <ul>
            {NAV_ITEMS.map((item) => (
              <li key={item.id}>
                <a href={`#${item.id}`}>{item.label}</a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="footer__doc">
          <h2 className="footer__title">Rasmiy hujjat</h2>
          <p>
            {OFFICIAL.docType} № {OFFICIAL.number}, {OFFICIAL.dateLabel}
          </p>
          <ul>
            <li>
              <a href="#rasmiy-hujjat">Hujjat haqida</a>
            </li>
            <li>
              <a href={OFFICIAL.pdfUrl} target="_blank" rel="noopener noreferrer">
                PDF ni ochish
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="container footer__bottom">
        <p>
          Sayt ma’lumotlari {OFFICIAL.dateLabel}dagi {OFFICIAL.number}-sonli buyruqqa asoslangan. Hujjatda bo‘lmagan
          ma’lumotlar “Ma’lumot kiritilmagan” yoki “Demo” deb belgilangan.
        </p>
        <a className="to-top" href="#bosh-sahifa">
          <Icon name="arrow" size={16} className="to-top__icon" />
          <span>Yuqoriga</span>
        </a>
      </div>
    </footer>
  )
}
