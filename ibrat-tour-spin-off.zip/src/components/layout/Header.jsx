import { useEffect, useState } from 'react'
import Logo from '../ui/Logo.jsx'
import Icon from '../ui/Icon.jsx'
import ThemeToggle from './ThemeToggle.jsx'
import useActiveSection from '../../hooks/useActiveSection.js'
import { NAV_ITEMS, SECTION_IDS } from '../../data/nav.js'

export default function Header({ theme, onToggleTheme }) {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const active = useActiveSection(SECTION_IDS)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (!open) return undefined
    const onKey = (event) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open])

  useEffect(() => {
    const query = window.matchMedia('(min-width: 1200px)')
    const onChange = (event) => {
      if (event.matches) setOpen(false)
    }
    query.addEventListener('change', onChange)
    return () => query.removeEventListener('change', onChange)
  }, [])

  const close = () => setOpen(false)

  return (
    <header className={`header${scrolled ? ' is-scrolled' : ''}`}>
      <div className="container header__bar">
        <a className="brand" href="#bosh-sahifa" onClick={close} aria-label="IBRAT TOUR SPIN-OFF — bosh sahifa">
          <Logo size={38} />
          <span className="brand__text">
            <span className="brand__name">IBRAT TOUR</span>
            <span className="brand__sub">SPIN-OFF</span>
          </span>
        </a>

        <nav
          id="asosiy-menyu"
          className={`nav${open ? ' is-open' : ''}`}
          aria-label="Asosiy menyu"
        >
          <ul className="nav__list">
            {NAV_ITEMS.map((item) => (
              <li key={item.id}>
                <a
                  className={`nav__link${active === item.id ? ' is-active' : ''}`}
                  href={`#${item.id}`}
                  onClick={close}
                  aria-current={active === item.id ? 'true' : undefined}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="header__tools">
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
          <button
            type="button"
            className="icon-btn nav-toggle"
            aria-expanded={open}
            aria-controls="asosiy-menyu"
            aria-label={open ? 'Menyuni yopish' : 'Menyuni ochish'}
            onClick={() => setOpen((value) => !value)}
          >
            <Icon name={open ? 'close' : 'menu'} size={22} />
          </button>
        </div>
      </div>
    </header>
  )
}
