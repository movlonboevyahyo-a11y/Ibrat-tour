// Bodom (mindal) shaklidagi barglardan tuzilgan naqsh — sahifaning asosiy vizual belgisi.
const BIG_PETAL = 'M0 -10C16 -34 16 -66 0 -92C-16 -66 -16 -34 0 -10Z'
const SMALL_PETAL = 'M0 -12C9 -26 9 -42 0 -56C-9 -42 -9 -26 0 -12Z'

const BIG_ANGLES = [0, 45, 90, 135, 180, 225, 270, 315]
const SMALL_ANGLES = [22.5, 67.5, 112.5, 157.5, 202.5, 247.5, 292.5, 337.5]

export default function Rosette({ className = '' }) {
  return (
    <svg
      className={`rosette ${className}`.trim()}
      viewBox="-110 -110 220 220"
      aria-hidden="true"
      focusable="false"
    >
      <g className="rosette__spin">
        <circle className="rosette__ring" r="104" />
        <circle className="rosette__ring rosette__ring--dash" r="98" />
        {SMALL_ANGLES.map((angle, i) => (
          <path
            key={angle}
            className="rosette__petal rosette__petal--small"
            style={{ '--i': i + 8 }}
            transform={`rotate(${angle})`}
            d={SMALL_PETAL}
            pathLength="1"
          />
        ))}
        {BIG_ANGLES.map((angle, i) => (
          <path
            key={angle}
            className="rosette__petal"
            style={{ '--i': i }}
            transform={`rotate(${angle})`}
            d={BIG_PETAL}
            pathLength="1"
          />
        ))}
        <circle className="rosette__core-ring" r="15" />
        <circle className="rosette__core" r="6.5" />
      </g>
    </svg>
  )
}
