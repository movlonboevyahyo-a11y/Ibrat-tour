import Icon from './Icon.jsx'

// href bo‘lsa <a>, aks holda <button> chiqadi. external — yangi oynada ochiladi.
export default function Button({
  href,
  onClick,
  variant = 'primary',
  size = 'md',
  icon,
  external = false,
  className = '',
  children,
  ...rest
}) {
  const classes = `btn btn--${variant} btn--${size} ${className}`.trim()
  const content = (
    <>
      <span>{children}</span>
      {icon ? <Icon name={icon} size={18} /> : null}
    </>
  )

  if (href) {
    const extra = external ? { target: '_blank', rel: 'noopener noreferrer' } : {}
    return (
      <a className={classes} href={href} onClick={onClick} {...extra} {...rest}>
        {content}
      </a>
    )
  }

  return (
    <button type="button" className={classes} onClick={onClick} {...rest}>
      {content}
    </button>
  )
}
