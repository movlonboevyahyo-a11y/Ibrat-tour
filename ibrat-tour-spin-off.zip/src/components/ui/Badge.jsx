export default function Badge({ tone = 'demo', children }) {
  return <span className={`badge badge--${tone}`}>{children}</span>
}
