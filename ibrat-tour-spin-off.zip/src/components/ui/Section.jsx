export default function Section({ id, title, lead, aside, tone = 'plain', className = '', children }) {
  return (
    <section id={id} className={`section section--${tone} ${className}`.trim()} aria-labelledby={`${id}-title`}>
      <div className="container">
        <header className="section__head reveal">
          <div className="section__head-main">
            <h2 id={`${id}-title`} className="section__title">
              {title}
            </h2>
            {lead ? <p className="section__lead">{lead}</p> : null}
          </div>
          {aside ? <div className="section__aside">{aside}</div> : null}
        </header>
        {children}
      </div>
    </section>
  )
}
