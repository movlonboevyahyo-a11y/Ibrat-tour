// Rasmiy IBRAT TOUR logotipi (public/logo.png). Kvadrat PNG, o‘zida dumaloq nishonni saqlaydi,
// shuning uchun elementni o‘zini aylana shaklida ko‘rsatamiz.
export default function Logo({ size = 36, className = '' }) {
  return (
    <img
      className={`logo ${className}`.trim()}
      src="/logo.png"
      width={size}
      height={size}
      alt="IBRAT TOUR SPIN-OFF"
      style={{ width: size, height: size, borderRadius: '50%', display: 'block', objectFit: 'cover' }}
    />
  )
}
