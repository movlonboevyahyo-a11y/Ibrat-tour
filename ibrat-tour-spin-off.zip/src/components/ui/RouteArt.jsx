import { useId } from 'react'

// Marshrut kartochkalari uchun vektor illyustratsiyalar (tashqi rasm kerak emas — tez va ishonchli).
function Heritage({ id }) {
  return (
    <>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#27357a" />
          <stop offset=".62" stopColor="#d9647a" />
          <stop offset="1" stopColor="#f6b25e" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-sky)`} />
      <circle cx="312" cy="128" r="34" fill="#ffd98f" opacity=".95" />
      <g fill="#141c46">
        <rect x="96" y="96" width="12" height="112" />
        <path d="M94 96h16l-8-16z" />
        <rect x="292" y="96" width="12" height="112" />
        <path d="M290 96h16l-8-16z" />
        <rect x="132" y="168" width="136" height="40" />
        <path d="M140 168a60 60 0 0 1 120 0z" />
        <rect x="196" y="100" width="8" height="12" />
        <circle cx="200" cy="96" r="4" />
      </g>
      <path d="M180 208v-24a20 20 0 0 1 40 0v24z" fill="#f6b25e" opacity=".85" />
      <g stroke="#f6b25e" strokeWidth="1.4" opacity=".5" fill="none">
        <path d="M200 108v60M170 122c8 12 14 28 16 46M230 122c-8 12-14 28-16 46" />
      </g>
      <rect y="208" width="400" height="52" fill="#0d1338" />
    </>
  )
}

function Pilgrim({ id }) {
  const stars = [
    [40, 40], [90, 70], [140, 30], [230, 50], [270, 90], [60, 110], [180, 90], [350, 30], [370, 110],
  ]
  return (
    <>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#080f26" />
          <stop offset="1" stopColor="#1f3a8a" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-sky)`} />
      {stars.map(([x, y]) => (
        <circle key={`${x}-${y}`} cx={x} cy={y} r="1.6" fill="#fff" opacity=".8" />
      ))}
      <circle cx="318" cy="66" r="24" fill="#f2b544" />
      <circle cx="328" cy="60" r="21" fill="#0f1c52" />
      <g fill="#2a3f97">
        <rect x="150" y="150" width="100" height="60" />
        <path d="M156 150a44 44 0 0 1 88 0z" />
        <rect x="120" y="110" width="10" height="100" />
        <path d="M118 110h14l-7-16z" />
        <rect x="270" y="110" width="10" height="100" />
        <path d="M268 110h14l-7-16z" />
      </g>
      <g fill="#f2b544">
        <rect x="170" y="172" width="8" height="16" rx="4" />
        <rect x="196" y="172" width="8" height="16" rx="4" />
        <rect x="222" y="172" width="8" height="16" rx="4" />
      </g>
      <rect y="210" width="400" height="50" fill="#060c20" />
    </>
  )
}

function Gastro({ id }) {
  return (
    <>
      <defs>
        <linearGradient id={`${id}-bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#c2334d" />
          <stop offset="1" stopColor="#6b1a3a" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-bg)`} />
      <g stroke="#fff" strokeWidth="3" strokeLinecap="round" fill="none" opacity=".55">
        <path d="M170 116c-14-16 12-28-2-46" />
        <path d="M205 112c-14-16 12-28-2-46" />
        <path d="M240 116c-14-16 12-28-2-46" />
      </g>
      <ellipse cx="200" cy="224" rx="130" ry="14" fill="#000" opacity=".22" />
      <path d="M98 140h204c0 46-40 78-102 78S98 186 98 140z" fill="#f8efe2" />
      <ellipse cx="200" cy="140" rx="102" ry="20" fill="#e9dcc8" />
      <ellipse cx="200" cy="136" rx="92" ry="17" fill="#f2b544" />
      <g fill="#e2792f">
        <circle cx="160" cy="132" r="5" />
        <circle cx="196" cy="140" r="5" />
        <circle cx="232" cy="130" r="5" />
        <circle cx="214" cy="146" r="4" />
      </g>
      <g fill="#fff8e6">
        <circle cx="178" cy="142" r="3" />
        <circle cx="246" cy="140" r="3" />
        <circle cx="140" cy="140" r="3" />
      </g>
    </>
  )
}

function Mountain({ id }) {
  return (
    <>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#12276b" />
          <stop offset="1" stopColor="#7bb7dd" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-sky)`} />
      <circle cx="90" cy="70" r="26" fill="#ffe6a3" opacity=".9" />
      <polygon points="0,200 90,96 150,150 214,66 300,180 400,110 400,260 0,260" fill="#3f63a8" />
      <polygon points="214,66 192,98 204,92 214,104 224,92 238,100" fill="#f3f7ff" />
      <polygon points="90,96 74,118 84,114 92,122 102,112 110,118" fill="#f3f7ff" />
      <polygon points="0,236 100,150 170,214 252,128 340,224 400,176 400,260 0,260" fill="#17306b" />
      <g fill="#0d1f4d">
        <polygon points="40,260 52,220 64,260" />
        <polygon points="66,260 80,208 94,260" />
        <polygon points="320,260 332,224 344,260" />
        <polygon points="346,260 360,214 374,260" />
      </g>
    </>
  )
}

function Agro({ id }) {
  return (
    <>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#a9dbe9" />
          <stop offset="1" stopColor="#fbeeb9" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-sky)`} />
      <circle cx="310" cy="66" r="28" fill="#f2b544" />
      <path d="M0 176Q100 128 210 170T400 150V260H0Z" fill="#5aa565" />
      <path d="M0 214Q120 172 240 208T400 190V260H0Z" fill="#2f7d52" />
      <g stroke="#1f5a3a" strokeWidth="2" fill="none" opacity=".6">
        <path d="M0 232Q120 196 240 228T400 212" />
        <path d="M0 246Q120 212 240 242T400 228" />
      </g>
      <rect x="92" y="116" width="8" height="46" fill="#5b3a29" />
      <circle cx="96" cy="106" r="26" fill="#2f7d52" />
      <circle cx="80" cy="120" r="16" fill="#3f9563" />
      <circle cx="114" cy="118" r="16" fill="#3f9563" />
    </>
  )
}

function Study({ id }) {
  return (
    <>
      <defs>
        <linearGradient id={`${id}-bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1a2a6c" />
          <stop offset="1" stopColor="#1fa6a0" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-bg)`} />
      <g fill="none" stroke="#fff" strokeOpacity=".28" strokeWidth="2">
        <circle cx="200" cy="140" r="96" />
        <ellipse cx="200" cy="140" rx="96" ry="34" />
        <ellipse cx="200" cy="140" rx="40" ry="96" />
        <path d="M104 140h192M200 44v192" />
      </g>
      <path
        d="M70 196C130 60 260 60 322 138"
        fill="none"
        stroke="#f2b544"
        strokeWidth="3"
        strokeDasharray="2 9"
        strokeLinecap="round"
      />
      <circle cx="322" cy="138" r="9" fill="#c2334d" />
      <circle cx="322" cy="138" r="3.5" fill="#fff" />
      <g transform="translate(206 74) rotate(8)" fill="#fff">
        <path d="M0 0l30 12-30 12 6-12z" />
      </g>
      <circle cx="70" cy="196" r="6" fill="#f2b544" />
    </>
  )
}

function Registon({ id }) {
  return (
    <>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1b2a63" />
          <stop offset=".55" stopColor="#c2577a" />
          <stop offset="1" stopColor="#f6b25e" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-sky)`} />
      <circle cx="334" cy="92" r="28" fill="#ffd98f" opacity=".9" />
      <rect y="214" width="400" height="46" fill="#120f2a" />
      {/* chap tarafdagi madrasa */}
      <g fill="#15193f">
        <rect x="46" y="84" width="14" height="130" />
        <path d="M44 84h18l-9-18z" />
        <rect x="108" y="84" width="14" height="130" />
        <path d="M106 84h18l-9-18z" />
        <rect x="60" y="126" width="48" height="88" />
        <path d="M64 126a20 20 0 0 1 40 0z" fill="#0e1230" />
      </g>
      {/* markaziy gumbaz */}
      <circle cx="200" cy="108" r="30" fill="#1fa6a0" opacity=".92" />
      <path d="M200 78a30 30 0 0 1 0 60" fill="none" stroke="#e8fbf8" strokeWidth="2" opacity=".5" />
      <g fill="#171c48">
        <rect x="176" y="150" width="48" height="64" />
        <path d="M180 150a20 20 0 0 1 40 0z" fill="#10142f" />
      </g>
      {/* o‘ng tarafdagi madrasa */}
      <g fill="#15193f">
        <rect x="292" y="84" width="14" height="130" />
        <path d="M290 84h18l-9-18z" />
        <rect x="354" y="84" width="14" height="130" />
        <path d="M352 84h18l-9-18z" />
        <rect x="306" y="126" width="48" height="88" />
        <path d="M310 126a20 20 0 0 1 40 0z" fill="#0e1230" />
      </g>
      {/* feruza naqsh chiziqlari */}
      <g stroke="#3fd9c7" strokeWidth="2" opacity=".65" fill="none">
        <path d="M64 170h40M64 182h40M310 170h40M310 182h40M180 176h40M180 188h40" />
      </g>
    </>
  )
}

function IslomMarkazi({ id }) {
  return (
    <>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#bfe3f5" />
          <stop offset="1" stopColor="#eef6e4" />
        </linearGradient>
        <linearGradient id={`${id}-dome`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#8fb8c9" />
          <stop offset="1" stopColor="#4f7f95" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id}-sky)`} />
      <circle cx="80" cy="58" r="26" fill="#fff6d8" opacity=".9" />
      <rect y="224" width="400" height="36" fill="#cdd9c0" />
      <rect x="60" y="188" width="60" height="36" fill="#f1ede1" />
      <rect x="280" y="188" width="60" height="36" fill="#f1ede1" />
      <rect x="120" y="150" width="160" height="74" rx="4" fill="#e7e2d4" />
      <g stroke="#cfc8b4" strokeWidth="2">
        <line x1="140" y1="150" x2="140" y2="224" />
        <line x1="165" y1="150" x2="165" y2="224" />
        <line x1="190" y1="150" x2="190" y2="224" />
        <line x1="215" y1="150" x2="215" y2="224" />
        <line x1="240" y1="150" x2="240" y2="224" />
        <line x1="260" y1="150" x2="260" y2="224" />
      </g>
      <path d="M118 150a82 60 0 0 1 164 0z" fill={`url(#${id}-dome)`} />
      <g stroke="#2f5567" strokeWidth="1.6" opacity=".6" fill="none">
        <path d="M150 150a50 60 0 0 1 16-58" />
        <path d="M175 150a50 62 0 0 1 10-60" />
        <path d="M200 150v-62" />
        <path d="M225 150a50 62 0 0 0 -10-60" />
        <path d="M250 150a50 60 0 0 0 -16-58" />
      </g>
      <rect x="196" y="70" width="8" height="16" fill="#2f5567" />
      <circle cx="200" cy="84" r="6" fill="#2f5567" />
      <g fill="#4c8a52">
        <circle cx="46" cy="196" r="16" />
        <circle cx="354" cy="196" r="16" />
      </g>
      <rect x="42" y="206" width="8" height="18" fill="#6b4a2f" />
      <rect x="350" y="206" width="8" height="18" fill="#6b4a2f" />
    </>
  )
}

const SCENES = {
  heritage: Heritage,
  pilgrim: Pilgrim,
  gastro: Gastro,
  mountain: Mountain,
  agro: Agro,
  study: Study,
  registon: Registon,
  'islom-markazi': IslomMarkazi,
}

export default function RouteArt({ variant = 'heritage', className = '' }) {
  const rawId = useId()
  const uid = `art${rawId.replace(/[^a-zA-Z0-9]/g, '')}`
  const Scene = SCENES[variant] || Heritage
  return (
    <svg
      className={`route-art ${className}`.trim()}
      viewBox="0 0 400 260"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      focusable="false"
    >
      <Scene id={uid} />
    </svg>
  )
}
