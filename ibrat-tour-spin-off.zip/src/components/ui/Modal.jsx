import { useEffect, useRef } from 'react'
import Icon from './Icon.jsx'

// Standart <dialog> elementi: klaviatura fokusi va Esc tugmasi brauzer tomonidan boshqariladi.
export default function Modal({ open, onClose, titleId, children }) {
  const ref = useRef(null)

  useEffect(() => {
    const dialog = ref.current
    if (!dialog) return undefined
    if (open && !dialog.open) dialog.showModal()
    if (!open && dialog.open) dialog.close()
    document.documentElement.classList.toggle('no-scroll', open)
    return () => document.documentElement.classList.remove('no-scroll')
  }, [open])

  useEffect(() => {
    const dialog = ref.current
    if (!dialog) return undefined
    const handleClose = () => onClose()
    dialog.addEventListener('close', handleClose)
    return () => dialog.removeEventListener('close', handleClose)
  }, [onClose])

  const handleBackdrop = (event) => {
    if (event.target === event.currentTarget) onClose()
  }

  return (
    <dialog ref={ref} className="modal" aria-labelledby={titleId} onClick={handleBackdrop}>
      <div className="modal__panel">
        <button type="button" className="modal__close" onClick={onClose} aria-label="Oynani yopish">
          <Icon name="close" size={20} />
        </button>
        {children}
      </div>
    </dialog>
  )
}
