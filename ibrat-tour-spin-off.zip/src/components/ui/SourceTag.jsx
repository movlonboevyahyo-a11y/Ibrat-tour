import Icon from './Icon.jsx'

// Har bir bo‘limda ma’lumot qaysi rasmiy hujjatdan olinganini ko‘rsatadi.
export default function SourceTag({ children = 'Manba: buyruq, 3-band' }) {
  return (
    <a className="source-tag" href="#rasmiy-hujjat">
      <Icon name="file" size={15} />
      <span>{children}</span>
    </a>
  )
}
