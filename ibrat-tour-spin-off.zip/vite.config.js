import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base: './' — sayt GitHub Pages (username.github.io/repo/) da ham,
// Netlify/Vercel (domen ildizi) da ham bir xil ishlaydi.
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    target: 'es2019',
    sourcemap: false,
  },
})
